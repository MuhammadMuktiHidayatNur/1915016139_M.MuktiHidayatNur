import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  const Home({ Key? key }) : super(key: key);

  Widget myContainer(BuildContext context){
    var lebar = MediaQuery.of(context).size.width;
    return Container(
      margin: const EdgeInsets.only(
        bottom: 70
      ),
      width: lebar,
      height: 400,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("sandalcoklat.png")
        ),
      ),
      alignment: Alignment.bottomCenter,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: const [
          Text("Mojo Mokka",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text("Rp. 429.000",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      )
    );
  }

  Widget myContainer2(BuildContext context){
    var lebar = MediaQuery.of(context).size.width;
    return Container(
      margin: const EdgeInsets.only(
        bottom: 70
      ),
      width: lebar,
      height: 400,
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: AssetImage("sandalblaze.png")
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: const [
          Text("Saba Blaze",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text("Rp. 679.000",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontStyle: FontStyle.italic,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ) 
    );
  }

  Widget sizeSendal(){
    return Container(
      margin: const EdgeInsets.only(
        bottom: 50
      ),
      
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 100,
            height: 100,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.grey.shade500,
            ),
            child: const Text("39",
            textAlign: TextAlign.center,
            style: TextStyle(
              letterSpacing: 5,
              fontStyle: FontStyle.italic,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
            ),
          ),
          Container(
            width: 100,
            height: 100,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.grey.shade500,
                width: 5,
              )
            ),
            child: const Text("40",
            textAlign: TextAlign.center,
            style: TextStyle(
              letterSpacing: 5,
              color: Colors.black,
              fontStyle: FontStyle.italic,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
            ),
          ),
          Container(
            width: 100,
            height: 100,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Colors.grey.shade500,
                width: 5,
              )
            ),
            child: const Text("41",
            textAlign: TextAlign.center,
            style: TextStyle(
              letterSpacing: 5,
              color: Colors.black,
              fontStyle: FontStyle.italic,
              fontSize: 25,
              fontWeight: FontWeight.bold,
            ),
            ),
          ),
        ],
      ),
    );
  }

Widget tambahSendal(BuildContext context){
  var lebar = MediaQuery.of(context).size.width;
    return Container(
      margin: const EdgeInsets.only(
        bottom: 30, top: 50, left: 50, right: 50
      ),
      width: lebar,
      height: 100,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: Colors.grey.shade500,
      ),
      child: const Text("ADD TO CART ",
        textAlign: TextAlign.center,
        style: TextStyle(
          letterSpacing: 5,
          color: Colors.black,
          fontSize: 25,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget ukuran(){
    return Container(
      margin: const EdgeInsets.only(
        bottom: 50, top: 50,
      ),
      child: const Text("Size",
        style: TextStyle(
          letterSpacing: 5,
          fontSize: 15,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Center(
          child: Text("Posttest 2 M Mukti Hidayat Nur",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.black,
            ),
          ),
        ), 
        backgroundColor: Colors.white,
      ),
      body: ListView(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    myContainer(context),
                    myContainer2(context),
                  ],
                ),
              ),
              ukuran(),
              sizeSendal(),
              tambahSendal(context),
            ],
          ),
        ],
      ),
    );
  }
}