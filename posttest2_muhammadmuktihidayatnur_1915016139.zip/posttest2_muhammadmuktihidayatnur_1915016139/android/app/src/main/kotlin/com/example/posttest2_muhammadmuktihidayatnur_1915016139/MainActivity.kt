package com.example.posttest2_muhammadmuktihidayatnur_1915016139

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
